<div>
    
    <img src="https://www.shutterstock.com/shutterstock/photos/1862937556/display_1500/stock-photo-triangle-solid-black-golden-illustration-abstract-hd-download-1862937556.jpg" alt="">
    <h1>registration</h1>
</div>
<?php /**PATH G:\xampp7\htdocs\laravel_practice\laravel-live-wire\resources\views/livewire/register.blade.php ENDPATH**/ ?>