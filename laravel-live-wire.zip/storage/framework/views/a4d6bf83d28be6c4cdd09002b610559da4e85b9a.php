<html>
<head>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    

    <?php echo e($slot); ?>


    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH G:\xampp7\htdocs\laravel_practice\laravel-live-wire\resources\views/welcome.blade.php ENDPATH**/ ?>