<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <?php
        $details = \Adrianorosa\GeoLocation\GeoLocation::lookup('45.118.63.2');

        $office_lat = 23.809861231612796;
        $office_lon = 90.36154818440077;

        $user_lat = $details->getLatitude();
        $user_lon = $details->getLongitude();

        function findDistance($lat1, $lon1, $lat2, $lon2) {
            $R = 6371e3; // R is earth’s radius
            // $lat1 = 23.18489670753479; // starting point lat
            // $lat2 = 32.726601;         // ending point lat
            // $lon1 = 72.62524545192719; // starting point lon
            // $lon2 = 74.857025;         // ending point lon
            $lat1radians = toRadians($lat1);
            $lat2radians = toRadians($lat2);

            $latRadians = toRadians($lat2-$lat1);
            $lonRadians = toRadians($lon2-$lon1);

            $a = sin($latRadians/2) * sin($latRadians/2) +
                    cos($lat1radians) * cos($lat2radians) *
                    sin($lonRadians/2) * sin($lonRadians/2);
            $c = 2 * atan2(sqrt($a), sqrt(1-$a));

            $d = $R * $c;

            return $d;
        }

        function toRadians($val)
        {
            $PI = 3.1415926535;
            return $val / 180.0 * $PI;
        }
        // dd(
        //     $details->toArray(),
        //     findDistance($office_lat, $office_lon, 23.7104, 90.4074)
        // );

        $user_and_office_distance = findDistance($office_lat, $office_lon, $user_lat, $user_lon);
    ?>

        <h1>User distance: <?php echo e($user_and_office_distance); ?> meters </h1>

    <script>
        findDistance(23.809861231612796, 90.36154818440077, 23.7104, 90.4074);

        function findDistance(lat1, lon1, lat2, lon2) {
            var R = 6371e3; // R is earth’s radius
            // var lat1 = 23.18489670753479; // starting point lat
            // var lat2 = 32.726601;         // ending point lat
            // var lon1 = 72.62524545192719; // starting point lon
            // var lon2 = 74.857025;         // ending point lon
            var lat1radians = toRadians(lat1);
            var lat2radians = toRadians(lat2);

            var latRadians = toRadians(lat2-lat1);
            var lonRadians = toRadians(lon2-lon1);

            var a = Math.sin(latRadians/2) * Math.sin(latRadians/2) +
                    Math.cos(lat1radians) * Math.cos(lat2radians) *
                    Math.sin(lonRadians/2) * Math.sin(lonRadians/2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

            var d = R * c;

            return d;
        }

        function toRadians(val){
            var PI = 3.1415926535;
            return val / 180.0 * PI;
        }
    </script>
</body>
</html>
<?php /**PATH G:\xampp7\htdocs\laravel_practice\laravel-live-wire\resources\views/test.blade.php ENDPATH**/ ?>