<?php return array (
  'login' => 'App\\Http\\Livewire\\Login',
  'login-submit' => 'App\\Http\\Livewire\\LoginSubmit',
  'register' => 'App\\Http\\Livewire\\Register',
  'show-posts' => 'App\\Http\\Livewire\\ShowPosts',
  'user-details' => 'App\\Http\\Livewire\\UserDetails',
);