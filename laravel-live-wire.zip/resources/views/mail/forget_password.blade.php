your temporary password for my report bd is <br>
password: {{$password}}
<br>
please change it from your dashboard
