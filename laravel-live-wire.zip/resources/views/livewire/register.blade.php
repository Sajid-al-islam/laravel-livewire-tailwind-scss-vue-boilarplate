<div>
    {{-- The whole world belongs to you. --}}
    <img src="https://www.shutterstock.com/shutterstock/photos/1862937556/display_1500/stock-photo-triangle-solid-black-golden-illustration-abstract-hd-download-1862937556.jpg" alt="">
    <h1>registration</h1>
</div>
