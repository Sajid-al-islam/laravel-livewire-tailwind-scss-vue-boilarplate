<html>
<head>
    @livewireStyles
</head>
<body>
    {{-- @livewire('show-posts') --}}

    @yield('content')

    @livewireScripts
</body>
</html>
