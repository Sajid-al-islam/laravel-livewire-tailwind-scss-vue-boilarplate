<template>
  <h1>password</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
