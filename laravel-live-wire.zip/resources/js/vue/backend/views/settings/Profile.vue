<template>
  <h1>profiel setting</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
