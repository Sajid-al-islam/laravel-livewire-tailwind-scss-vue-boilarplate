<template>
    <li class="nav-item nav-search">
        <a class="nav-link nav-link-search">
            <i class="ficon" data-feather="search"></i>
        </a>
        <div class="search-input">
            <div class="search-input-icon"><i data-feather="search"></i></div>
            <input class="form-control input" type="text" placeholder="Explore Vuexy..." tabindex="-1"
                data-search="search">
            <div class="search-input-close"><i data-feather="x"></i></div>
            <ul class="search-list search-list-main"></ul>
        </div>
    </li>
</template>

<script>
export default {

}
</script>

<style>

</style>
