<template>
    <li class="nav-item">
        <a class="nav-link menu-toggle" href="#">
            <i class="ficon" data-feather="menu"></i>
        </a>
    </li>
</template>

<script>
export default {

}
</script>

<style>

</style>
