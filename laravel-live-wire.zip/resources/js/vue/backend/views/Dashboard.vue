<template>
    <section class="p-5">
        <div class="row">
            <!-- Invoice repeater -->
            <div class="col-12">
                <div v-for="i in 30" :key="i" class="card mb-5">
                    <div class="card-header">
                        <h4 class="card-title">Dashboard</h4>
                    </div>
                    <div class="card-body">
                        <p>welcome to Dashboard</p>
                    </div>
                </div>
            </div>
            <!-- /Invoice repeater -->
        </div>
    </section>
</template>

<script>
export default {};
</script>

<style>
</style>
