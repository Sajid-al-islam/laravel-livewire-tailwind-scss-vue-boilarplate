require('./bootstrap');
window.Turbolinks = require("turbolinks");
Turbolinks.start();
